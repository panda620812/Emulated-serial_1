#ifndef __CRC8_16_H
#define __CRC8_16_H
//#include "sys.h"	 
#include "stm32f10x.h"

uint16_t Get_Crc16(uint8_t *puchMsg,uint16_t usDataLen);
uint8_t Get_Crc8(uint8_t *ptr,uint16_t len);

#endif




























