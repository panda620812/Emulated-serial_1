#include <stdio.h>
#include "stm32f10x.h"
#include "cmsis_os2.h"
#include "stm32f10x_usart.h"


/*** �ض����׼���롢��׼�������׼����tty  ***/

//int stderr_putchar (int ch)
//{
//	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET) osThreadYield();
//	USART_SendData(USART1, (uint8_t) ch);
//	return ch;
//}

//int stdout_putchar (int ch)
//{
//	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET) osThreadYield();
//	USART_SendData(USART1, (uint8_t) ch);
//	return ch;
//}

//int stdin_getchar (void)
//{
//	while (USART_GetFlagStatus(USART1, USART_FLAG_RXNE) == RESET) osThreadYield();
//	return USART_ReceiveData(USART1);
//}

//void ttywrch (int ch)
//{
//	while (USART_GetFlagStatus(USART1, USART_FLAG_TXE) == RESET) osThreadYield();
//	USART_SendData(USART1, (uint8_t) ch);
//}

#pragma import(__use_no_semihosting)
//��׼����Ҫ��֧�ֺ���   ��û��ʹ��΢��ʱ����struct _FILE ��_sys_exit
struct __FILE
{
    int handle;

};

FILE __stdout;
//����_sys_exit()�Ա���ʹ�ð�����ģʽ
void _sys_exit(int x)
{
    x = x;
}

int fputc(int ch, FILE *f) //�ض��嵽��UART4
{
    while (USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET) osThreadYield();
    USART_SendData(USART3, (uint8_t) ch);
    return ch;
}

int fgetc(FILE *f)
{
    while (USART_GetFlagStatus(USART3, USART_FLAG_RXNE) == RESET) osThreadYield();
    return USART_ReceiveData(USART3);
}

