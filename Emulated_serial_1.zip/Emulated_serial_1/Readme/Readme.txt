Emulated serial 0-9600
参考  http://ziye334.blog.163.com/blog/static/224306191201452833850647
使用引脚中断、定时器中断、定时读取引脚状态
ausart.c
ausart.h
main.c